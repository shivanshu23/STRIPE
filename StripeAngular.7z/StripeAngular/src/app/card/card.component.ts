import { Component, OnInit, ViewChild } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

// Stripe
import { StripeService, StripeCardComponent, ElementOptions, ElementsOptions } from 'ngx-stripe';

@Component({
  selector: 'app-card',
  templateUrl: './card.component.html',
  styleUrls: ['./card.component.css']
})
export class CardComponent implements OnInit {

  @ViewChild(StripeCardComponent) card: StripeCardComponent;

  cardOptions: ElementOptions = {
    style: {
      base: {
        iconColor: '#666EE8',
        color: '#31325F',
        lineHeight: '40px',
        fontWeight: 300,
        fontFamily: '"Helvetica Neue", Helvetica, sans-serif',
        fontSize: '18px',
        '::placeholder': {
          color: '#CFD7E0'
        }
      }
    }
  };

  elementsOptions: ElementsOptions = {
    locale: 'en'
  };

  clientSecret: any;
  paymentIntentId: any;

  stripeTest: FormGroup;

  constructor(
    private fb: FormBuilder,
    private stripeService: StripeService,
    private http: HttpClient) { }

  ngOnInit() {
    this.stripeTest = this.fb.group({
      name: ['', [Validators.required]]
    });
  }

  buy() {
    const name = this.stripeTest.get('name').value;
    const headers = new HttpHeaders({
      'Content-Type': 'application/json'
    });

    const options = {
      headers: headers
    };

    // Create Payment Method
    this.stripeService.createPaymentMethod('card', this.card.getCard())
      .subscribe(result => {
        debugger;
        if (result.paymentMethod.id) {
          console.log(result.paymentMethod.id);

          const inputs = {
            paymentMethodID: result.paymentMethod.id
          };

          this.http.post('/api/stripe/', inputs, options).subscribe((data: any) => {
            debugger;

            if (data.status === 'requires_action') {
              this.clientSecret = data.result;
              // Handle Card for 3D Secure 2 Authentication.
              this.handleServerResponse(this.clientSecret);
            } else {
              console.log(data.status);
            }
          });
        } else {
          console.log('Error');
        }
      });
  }

  // Handle Server Response
  handleServerResponse(secret: any) {
    debugger;
    this.stripeService.handleCardAction(secret).subscribe((result) => {
      debugger
      if (result.error) {
        console.log('Error');
      } else {
        // Confirm Payment Intent now
        const headers = new HttpHeaders({
          'Content-Type': 'application/json'
        });
        const options = {
          headers: headers
        };
        debugger
        const inputs = {
          paymentIntentId: result.paymentIntent.id
        };

        this.http.post('/api/ConfirmPaymentIntent/', inputs, options).subscribe((data: any) => {
          if (data.status === 'succeeded') {
            console.log('payment Sucessfull');
          } else {
            console.log('Something went wrong we will try to contact you soon. Take Care');
          }
        });

        this.paymentIntentId = result.paymentIntent.id;
      }
    });
  }
}
