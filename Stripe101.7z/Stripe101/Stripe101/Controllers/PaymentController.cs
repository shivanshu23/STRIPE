﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Stripe;

namespace Stripe101.Controllers
{
    public class PaymentController : Controller
    {
        public IActionResult OnSession(string Id)
        {
            var service = new PaymentIntentService();
            var options = new PaymentIntentConfirmOptions
            {
                
                
            };
            var intent = service.Confirm(Id, options);

            return View();
        }


    }
}