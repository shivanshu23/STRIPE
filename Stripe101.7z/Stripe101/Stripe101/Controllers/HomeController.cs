﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Stripe;

namespace Stripe101.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index(string customerID, string sourceID)
        {
            if (customerID != null)
            {
                //Payment Intent Creation.....
                var paymentIntentService = new PaymentIntentService();
                var Options = new PaymentIntentCreateOptions
                {
                    Amount = 70000,
                    Currency = "usd",
                    CustomerId = customerID,
                    //SourceId = sourceID,
                    PaymentMethodId = sourceID,
                    Confirm = true,
                    ConfirmationMethod = "manual",
                    SetupFutureUsage = "off_session",                    

                    //OffSession = "one_off",
                };
                var intent = paymentIntentService.Create(Options);
                
                if (intent.Status == "requires_action")
                {
                    ViewBag.output = intent.Status;
                }

                //Passing Client Secret for Authentication
                ViewData["ClientSecret"] = intent.ClientSecret;
            }
          
            return View();
        }

        public IActionResult Authenticate()
        {

            return View();
        }



        public IActionResult Charge(string customerID, string sourceID)
        {
            //STEP 3
            //Payment Intent Creation.....
            var paymentIntentService = new PaymentIntentService();
            var createOptions = new PaymentIntentCreateOptions
            {
                Amount = 4000,
                Currency = "usd",
                CustomerId = customerID,
                SourceId = sourceID,
                Confirm = true,                

                //PaymentMethodId = paymentMethods.Data[0].Id,
                //OffSession = "one_off",
                //ConfirmationMethod = "manual",                
            };
             var intent = paymentIntentService.Create(createOptions);

            if(intent.Status == "requires_action")
            {
                TempData["output"] = intent.ClientSecret;
                TempData.Keep("output");
            }


            return RedirectToAction("Index");
        }



        //public IActionResult Charge(string stripeEmail, string stripeToken)
        //{
        //    var customers = new CustomerService();
        //    var charges = new ChargeService();

        //    var customer = customers.Create(new CustomerCreateOptions
        //    {
        //        Email = stripeEmail,
        //        Source = stripeToken
        //        //SourceToken = stripeToken
        //    });

        //    var charge = charges.Create(new ChargeCreateOptions
        //    {
        //        Amount = 500,
        //        Description = "Sample Charge",
        //        Currency = "usd",
        //        CustomerId = customer.Id
        //    });

        //    return View();
        //}

       
        public IActionResult Error()
        {
            return View();
        }
    }
}