﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Stripe;

namespace Stripe101.Controllers
{
    public class SetUpIntentController : Controller
    {
        public IActionResult SetUpIntent()
        {
            
            ////Step 1
            ////Create new payment method
            //var pmOption = new PaymentMethodCreateOptions
            //{
            //    Type = "card",
            //    Card = new PaymentMethodCardCreateOptions
            //    {
            //        Number = "4000002500003155",
            //        ExpMonth = 06,
            //        ExpYear = 2023,
            //        Cvc = "007"
            //    },
            //};

            //var pmService = new PaymentMethodService();
            //var paymentMethod = pmService.Create(pmOption);


            //// STEP 2
            //// Attach payment method to the customer:
            //var paymentMethodService = new PaymentMethodService();
            //var attachOptions = new PaymentMethodAttachOptions
            //{
            //    CustomerId = "cus_FNYV7hujdXGGrk"
            //};
            //var pm = paymentMethodService.Attach(paymentMethod.Id, attachOptions);


            //Step 3
            // Setup INTENT
            var setupIntentService = new SetupIntentService();
            var createOptions = new SetupIntentCreateOptions
            {
                CustomerId= "cus_FNYV7hujdXGGrk",
                PaymentMethodId= "pm_1EsnhcLSPm1V1qYOz0y1RrwQ",
                Usage = "off_session"
            };
            var intent = setupIntentService.Create(createOptions);
            

            ViewData["ClientSecret"] = intent.ClientSecret;
            
            return View();
        }
    }
}