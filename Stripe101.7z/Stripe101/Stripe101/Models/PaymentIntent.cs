﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Stripe101.Models
{
    public class PaymentIntent
    {
        public string CustomerID { get; set; }

        public string SourceID { get; set; }
    }
}
