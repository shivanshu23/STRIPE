﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace StripeWithAngular.Models
{
    public class paymentMethodModel
    {
        public string paymentMethodID { get; set; }
    }

    public class paymentIntentModel
    {
        public string paymentIntentId { get; set; }
    }
}
