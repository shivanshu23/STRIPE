﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Stripe;
using StripeWithAngular.Models;

namespace StripeWithAngular.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StripeController : ControllerBase
    {
        [HttpPost]
        public ActionResult PaymentIntent([FromBody] paymentMethodModel pmModel)
        {
            StripeConfiguration.ApiKey = "sk_test_Ugbxv7usd2CUpfCl8Xtq7udR";

            // Step 1
            // Attaching a payment method with a cusotmer
            var service = new PaymentMethodService();
            var options = new PaymentMethodAttachOptions
            {
                CustomerId = "cus_FPs8UwsaSNosa1",
            };
            var paymentMethod = service.Attach(pmModel.paymentMethodID, options);

            // Step 2
            // Creating Payment Intent
            var paymentIntentService = new PaymentIntentService();
            var Options = new PaymentIntentCreateOptions
            {
                Amount = 70000,
                Currency = "usd",
                CustomerId = "cus_FPs8UwsaSNosa1",
                PaymentMethodId = pmModel.paymentMethodID,
                Confirm = true,
                ConfirmationMethod = "manual",
                SetupFutureUsage = "off_session",
            };
            var intent = paymentIntentService.Create(Options);

            var secret = intent.ClientSecret;

            return Ok(new { result = secret, status = intent.Status });
        }        
    }   
}