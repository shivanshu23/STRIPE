﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Stripe;
using StripeWithAngular.Models;

namespace StripeWithAngular.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ConfirmPaymentIntentController : ControllerBase
    {
        [HttpPost]
        public ActionResult PaymentIntentConfirmation([FromBody] paymentIntentModel intentModel)
        {
            StripeConfiguration.ApiKey = "sk_test_Ugbxv7usd2CUpfCl8Xtq7udR";

            var service = new PaymentIntentService();
            var options = new PaymentIntentConfirmOptions
            { };
            var intent = service.Confirm(intentModel.paymentIntentId, options);

            return Ok(new { status = intent.Status });
        }
    }
}